const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const fs = require("fs");
fs.mkdirSync(DATA_DIR, { recursive: true });

const required = ["SESSION_SECRET", "ADMIN_PASSWORD"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing required environment variables:", missing.join(", "));
  process.exit(1);
}
if (process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters.");
  process.exit(1);
}
if (process.env.ADMIN_PASSWORD.length < 12) {
  console.error("ADMIN_PASSWORD must be at least 12 characters.");
  process.exit(1);
}

const db = new Database(path.join(DATA_DIR, "applications.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    country TEXT NOT NULL,
    amount INTEGER NOT NULL,
    purpose TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    status TEXT NOT NULL DEFAULT 'Pending'
  )
`);

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: DATA_DIR }),
  name: "kashagi.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: 8 * 60 * 60 * 1000
  }
}));

const applicationLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many applications from this connection. Please try again later." }
});
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false
});

const insertApplication = db.prepare(`
  INSERT INTO applications (full_name, phone, email, country, amount, purpose)
  VALUES (@full_name, @phone, @email, @country, @amount, @purpose)
`);

function clean(value, max) {
  return String(value || "").trim().replace(/[<>]/g, "").slice(0, max);
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Please sign in again." });
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

async function sendTelegram(application) {
  if (!process.env.TELEGRAM_BOT_TOKEN || !process.env.TELEGRAM_CHAT_ID) return;
  const message = [
    "New Kashagi Loans application",
    `Reference: #${application.id}`,
    `Name: ${application.full_name}`,
    `Phone: ${application.phone}`,
    `Email: ${application.email || "Not provided"}`,
    `Country: ${application.country}`,
    `Amount requested: USD ${application.amount}`,
    `Purpose: ${application.purpose}`,
    "Status: Pending review"
  ].join("\n");
  const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: process.env.TELEGRAM_CHAT_ID, text: message })
  });
  if (!response.ok) throw new Error(`Telegram API returned ${response.status}`);
  const result = await response.json();
  if (!result.ok) throw new Error("Telegram rejected the notification");
}

async function sendEmail(application) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, NOTIFY_EMAIL, SMTP_FROM } = process.env;
  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS || !NOTIFY_EMAIL) return;
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
  await transporter.sendMail({
    from: SMTP_FROM || SMTP_USER,
    to: NOTIFY_EMAIL,
    subject: `New Kashagi Loans application #${application.id}`,
    text: [
      "A new loan application has been received.",
      `Reference: #${application.id}`,
      `Name: ${application.full_name}`,
      `Phone: ${application.phone}`,
      `Email: ${application.email || "Not provided"}`,
      `Country: ${application.country}`,
      `Amount requested: USD ${application.amount}`,
      `Purpose: ${application.purpose}`,
      "Status: Pending review"
    ].join("\n")
  });
}

app.post("/api/applications", applicationLimiter, async (req, res) => {
  // Honeypot field helps filter basic automated spam.
  if (req.body.website) return res.json({ ok: true, message: "Application received." });

  const full_name = clean(req.body.full_name, 100);
  const phone = clean(req.body.phone, 30);
  const email = clean(req.body.email, 150);
  const country = clean(req.body.country, 60);
  const amount = Number(req.body.amount);
  const purpose = clean(req.body.purpose, 500);

  if (full_name.length < 2 || !/^[+0-9() .-]{7,30}$/.test(phone) ||
      (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) ||
      country !== "Zimbabwe" || !Number.isInteger(amount) || amount < 10 || amount > 1000 ||
      purpose.length < 5) {
    return res.status(400).json({ error: "Please check your details. Applications are for Zimbabwe residents and amounts from USD 10 to USD 1,000." });
  }

  const record = { full_name, phone, email, country, amount, purpose };
  const info = insertApplication.run(record);
  const application = { id: Number(info.lastInsertRowid), ...record };

  // The application is saved even if a notification provider is temporarily unavailable.
  const results = await Promise.allSettled([sendTelegram(application), sendEmail(application)]);
  results.forEach((r, i) => {
    if (r.status === "rejected") console.error(i === 0 ? "Telegram notification failed:" : "Email notification failed:", r.reason.message);
  });
  res.status(201).json({ ok: true, reference: application.id, message: "Your application has been received for review." });
});

app.post("/api/admin/login", loginLimiter, (req, res) => {
  if (!safeEqual(req.body.password || "", process.env.ADMIN_PASSWORD)) {
    return res.status(401).json({ error: "Incorrect password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a secure session." });
    req.session.admin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/applications", requireAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM applications ORDER BY id DESC LIMIT 500").all();
  res.json(rows);
});
app.patch("/api/admin/applications/:id", requireAdmin, (req, res) => {
  const status = clean(req.body.status, 30);
  if (!["Pending", "Under review", "Approved", "Declined"].includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }
  const result = db.prepare("UPDATE applications SET status = ? WHERE id = ?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Application not found." });
  res.json({ ok: true });
});
app.get("/api/admin/me", requireAdmin, (req, res) => res.json({ ok: true }));

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Kashagi Loans listening on port ${PORT}`));
