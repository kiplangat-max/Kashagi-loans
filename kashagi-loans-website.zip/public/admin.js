const loginArea = document.getElementById("login-area");
const dashboard = document.getElementById("dashboard");
const rows = document.getElementById("applications");
const loginMessage = document.getElementById("login-message");
async function api(url, options={}) {
  const r = await fetch(url, { ...options, headers: { "Content-Type":"application/json", ...(options.headers||{}) }});
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Request failed");
  return data;
}
function showDashboard() { loginArea.hidden = true; dashboard.hidden = false; loadApplications(); }
async function loadApplications() {
  try {
    const data = await api("/api/admin/applications");
    rows.replaceChildren();
    data.forEach(item => {
      const tr = document.createElement("tr");
      const cells = [
        `#${item.id}\n${item.created_at}`,
        item.full_name,
        `${item.phone}\n${item.email || ""}`,
        `USD ${item.amount}`,
        item.purpose
      ];
      cells.forEach(value => { const td=document.createElement("td"); td.textContent=value; tr.appendChild(td); });
      const td=document.createElement("td");
      const select=document.createElement("select");
      ["Pending","Under review","Approved","Declined"].forEach(s=>{const o=document.createElement("option");o.value=s;o.textContent=s;if(s===item.status)o.selected=true;select.appendChild(o);});
      select.addEventListener("change", async()=>{try{await api(`/api/admin/applications/${item.id}`,{method:"PATCH",body:JSON.stringify({status:select.value})});}catch(e){alert(e.message);}});
      td.appendChild(select);tr.appendChild(td);rows.appendChild(tr);
    });
    document.getElementById("dash-message").textContent = `${data.length} most recent application(s). Refresh the page to reload.`;
  } catch(e) { document.getElementById("dash-message").textContent=e.message; }
}
document.getElementById("login-form").addEventListener("submit", async e=>{
  e.preventDefault();loginMessage.textContent="Signing in…";
  try { await api("/api/admin/login",{method:"POST",body:JSON.stringify({password:document.getElementById("password").value})});showDashboard(); }
  catch(err){loginMessage.textContent=err.message;}
});
document.getElementById("logout").addEventListener("click",async()=>{try{await api("/api/admin/logout",{method:"POST"});}finally{dashboard.hidden=true;loginArea.hidden=false;}});
api("/api/admin/me").then(showDashboard).catch(()=>{});
