document.getElementById("year").textContent = new Date().getFullYear();
const form = document.getElementById("application-form");
const message = document.getElementById("form-message");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.className = "";
  message.textContent = "Submitting your application securely…";
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/applications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Unable to submit application.");
    message.className = "success";
    message.textContent = `${result.message} Your reference number is #${result.reference}.`;
    form.reset();
  } catch (error) {
    message.className = "error";
    message.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
